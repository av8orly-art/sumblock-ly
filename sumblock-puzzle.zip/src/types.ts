export type GameMode = 'classic' | 'time';

export interface Block {
  id: string;
  value: number;
  row: number;
  col: number;
  isRemoving?: boolean;
}

export interface GameState {
  grid: (Block | null)[][];
  target: number;
  score: number;
  level: number;
  gameOver: boolean;
  selectedIds: string[];
  mode: GameMode;
  timeLeft: number;
  totalTime: number;
}

export const GRID_ROWS = 10;
export const GRID_COLS = 7;
export const INITIAL_ROWS = 4;
export const MAX_TARGET = 20;
export const MIN_TARGET = 5;
export const TIME_LIMIT = 10; // seconds per round in time mode
