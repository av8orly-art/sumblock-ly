import { Block, GRID_COLS, GRID_ROWS } from './types';

export const generateId = () => Math.random().toString(36).substring(2, 9);

export const createRandomBlock = (row: number, col: number): Block => ({
  id: generateId(),
  value: Math.floor(Math.random() * 9) + 1,
  row,
  col,
});

export const createInitialGrid = (initialRows: number): (Block | null)[][] => {
  const grid: (Block | null)[][] = Array.from({ length: GRID_ROWS }, () =>
    Array.from({ length: GRID_COLS }, () => null)
  );

  for (let r = GRID_ROWS - initialRows; r < GRID_ROWS; r++) {
    for (let c = 0; c < GRID_COLS; c++) {
      grid[r][c] = createRandomBlock(r, c);
    }
  }

  return grid;
};

export const getNewTarget = (min: number, max: number) => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

export const checkGameOver = (grid: (Block | null)[][]): boolean => {
  // If any block is in the top row (row 0), it's game over
  return grid[0].some(cell => cell !== null);
};

export const shiftBlocksDown = (grid: (Block | null)[][]): (Block | null)[][] => {
  const newGrid: (Block | null)[][] = Array.from({ length: GRID_ROWS }, () =>
    Array.from({ length: GRID_COLS }, () => null)
  );

  for (let c = 0; c < GRID_COLS; c++) {
    let writeRow = GRID_ROWS - 1;
    for (let r = GRID_ROWS - 1; r >= 0; r--) {
      if (grid[r][c]) {
        newGrid[writeRow][c] = { ...grid[r][c]!, row: writeRow, col: c };
        writeRow--;
      }
    }
  }

  return newGrid;
};

export const addNewRowAtBottom = (grid: (Block | null)[][]): (Block | null)[][] => {
  // First, shift everything UP
  const newGrid: (Block | null)[][] = Array.from({ length: GRID_ROWS }, () =>
    Array.from({ length: GRID_COLS }, () => null)
  );

  for (let r = 1; r < GRID_ROWS; r++) {
    for (let c = 0; c < GRID_COLS; c++) {
      if (grid[r][c]) {
        newGrid[r - 1][c] = { ...grid[r][c]!, row: r - 1, col: c };
      }
    }
  }

  // Add new row at the bottom
  for (let c = 0; c < GRID_COLS; c++) {
    newGrid[GRID_ROWS - 1][c] = createRandomBlock(GRID_ROWS - 1, c);
  }

  return newGrid;
};
