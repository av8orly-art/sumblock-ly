# SumBlock Puzzle Deployment Guide

This project is a React + Vite application ready to be deployed to Vercel.

## 1. Sync to GitHub

1. Create a new repository on [GitHub](https://github.com/new).
2. Open your terminal in the project root.
3. Initialize git and push to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: SumBlock Puzzle"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
   git push -u origin main
   ```

## 2. Deploy to Vercel

1. Go to [Vercel](https://vercel.com/new).
2. Import your GitHub repository.
3. **Environment Variables**:
   - If your game uses the Gemini API, add `GEMINI_API_KEY` in the "Environment Variables" section of the Vercel project settings.
4. Click **Deploy**.

## 3. Configuration Notes

- **Build Command**: `npm run build`
- **Output Directory**: `dist`
- **Framework Preset**: Vite (detected automatically)
- **SPA Routing**: Handled by `vercel.json`.
