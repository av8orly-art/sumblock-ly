/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  RotateCcw, 
  Play, 
  Clock, 
  Zap, 
  Pause, 
  Settings, 
  ChevronLeft,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { 
  GameMode, 
  GameState, 
  Block, 
  GRID_ROWS, 
  GRID_COLS, 
  INITIAL_ROWS, 
  MAX_TARGET, 
  MIN_TARGET, 
  TIME_LIMIT 
} from './types';
import { 
  createInitialGrid, 
  getNewTarget, 
  checkGameOver, 
  addNewRowAtBottom, 
  shiftBlocksDown 
} from './utils';

export default function App() {
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const startGame = (mode: GameMode) => {
    setGameState({
      grid: createInitialGrid(INITIAL_ROWS),
      target: getNewTarget(MIN_TARGET, MAX_TARGET),
      score: 0,
      level: 1,
      gameOver: false,
      selectedIds: [],
      mode,
      timeLeft: TIME_LIMIT,
      totalTime: TIME_LIMIT,
    });
    setIsPaused(false);
  };

  const resetGame = () => {
    if (gameState) {
      startGame(gameState.mode);
    }
  };

  const handleBlockClick = (block: Block) => {
    if (!gameState || gameState.gameOver || isPaused) return;

    setGameState(prev => {
      if (!prev) return null;
      
      const isSelected = prev.selectedIds.includes(block.id);
      let newSelectedIds: string[];

      if (isSelected) {
        newSelectedIds = prev.selectedIds.filter(id => id !== block.id);
      } else {
        newSelectedIds = [...prev.selectedIds, block.id];
      }

      // Calculate current sum
      const currentSum = newSelectedIds.reduce((sum, id) => {
        const b = prev.grid.flat().find(item => item?.id === id);
        return sum + (b?.value || 0);
      }, 0);

      if (currentSum === prev.target) {
        // Success! Clear blocks
        confetti({
          particleCount: 40,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#10b981', '#34d399', '#6ee7b7']
        });

        const newGrid = prev.grid.map(row => 
          row.map(cell => (cell && newSelectedIds.includes(cell.id) ? null : cell))
        );

        const shiftedGrid = shiftBlocksDown(newGrid);
        
        // In classic mode, add a new row after each success
        let finalGrid = shiftedGrid;
        if (prev.mode === 'classic') {
          finalGrid = addNewRowAtBottom(shiftedGrid);
        }

        const isGameOver = checkGameOver(finalGrid);

        return {
          ...prev,
          grid: finalGrid,
          score: prev.score + (newSelectedIds.length * 10),
          target: getNewTarget(MIN_TARGET, MAX_TARGET),
          selectedIds: [],
          gameOver: isGameOver,
          timeLeft: prev.mode === 'time' ? TIME_LIMIT : prev.timeLeft,
        };
      } else if (currentSum > prev.target) {
        // Exceeded target, clear selection
        return {
          ...prev,
          selectedIds: [],
        };
      }

      return {
        ...prev,
        selectedIds: newSelectedIds,
      };
    });
  };

  // Timer logic for Time Mode
  useEffect(() => {
    if (gameState?.mode === 'time' && !gameState.gameOver && !isPaused) {
      timerRef.current = setInterval(() => {
        setGameState(prev => {
          if (!prev) return null;
          if (prev.timeLeft <= 0) {
            // Time's up! Add a row and reset timer
            const newGrid = addNewRowAtBottom(prev.grid);
            const isGameOver = checkGameOver(newGrid);
            return {
              ...prev,
              grid: newGrid,
              timeLeft: TIME_LIMIT,
              gameOver: isGameOver,
              selectedIds: [], // Clear selection on time out
            };
          }
          return {
            ...prev,
            timeLeft: prev.timeLeft - 0.1,
          };
        });
      }, 100);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [gameState?.mode, gameState?.gameOver, isPaused]);

  const currentSum = gameState?.selectedIds.reduce((sum, id) => {
    const b = gameState.grid.flat().find(item => item?.id === id);
    return sum + (b?.value || 0);
  }, 0) || 0;

  if (!gameState) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 grid-pattern">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-8 max-w-md w-full"
        >
          <div className="space-y-2">
            <h1 className="text-6xl font-bold tracking-tighter text-emerald-500 italic">
              SUM<span className="text-zinc-100">BLOCK</span>
            </h1>
            <p className="text-zinc-400 font-mono text-sm uppercase tracking-widest">Mathematical Elimination</p>
          </div>

          <div className="grid gap-4">
            <button 
              onClick={() => startGame('classic')}
              className="group relative flex items-center justify-between p-6 bg-zinc-900 border border-zinc-800 rounded-2xl hover:border-emerald-500/50 transition-all text-left"
            >
              <div>
                <h3 className="text-xl font-bold text-zinc-100">Classic Mode</h3>
                <p className="text-sm text-zinc-500">New row after every success. Survival of the fastest.</p>
              </div>
              <Zap className="w-8 h-8 text-emerald-500 group-hover:scale-110 transition-transform" />
            </button>

            <button 
              onClick={() => startGame('time')}
              className="group relative flex items-center justify-between p-6 bg-zinc-900 border border-zinc-800 rounded-2xl hover:border-amber-500/50 transition-all text-left"
            >
              <div>
                <h3 className="text-xl font-bold text-zinc-100">Time Mode</h3>
                <p className="text-sm text-zinc-500">Beat the clock. Every second counts.</p>
              </div>
              <Clock className="w-8 h-8 text-amber-500 group-hover:scale-110 transition-transform" />
            </button>
          </div>

          <div className="pt-8 border-t border-zinc-900 flex justify-center gap-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-zinc-100">0</div>
              <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-mono">High Score</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-zinc-100">0</div>
              <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-mono">Games Played</div>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-zinc-950 text-zinc-100 font-sans selection:bg-emerald-500/30">
      {/* Header */}
      <header className="p-4 flex items-center justify-between border-b border-zinc-900 bg-zinc-950/50 backdrop-blur-md sticky top-0 z-20">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setGameState(null)}
            className="p-2 hover:bg-zinc-900 rounded-lg transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-lg font-bold tracking-tight">
              {gameState.mode === 'classic' ? 'CLASSIC' : 'TIME ATTACK'}
            </h2>
            <div className="flex items-center gap-2 text-[10px] font-mono text-zinc-500 uppercase tracking-widest">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Live Session
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3 py-1 bg-zinc-900 rounded-full border border-zinc-800 flex items-center gap-2">
            <Trophy className="w-3.5 h-3.5 text-amber-500" />
            <span className="text-sm font-bold font-mono">{gameState.score}</span>
          </div>
          <button 
            onClick={() => setIsPaused(!isPaused)}
            className="p-2 bg-zinc-900 hover:bg-zinc-800 rounded-lg border border-zinc-800 transition-colors"
          >
            {isPaused ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Game Board */}
      <main className="flex-1 flex flex-col items-center justify-center p-4 relative overflow-hidden">
        {/* Background Decorative Elements */}
        <div className="absolute inset-0 grid-pattern opacity-20 pointer-events-none" />
        
        {/* Target Display */}
        <div className="mb-8 text-center space-y-1 relative z-10">
          <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-[0.2em]">Target Sum</div>
          <motion.div 
            key={gameState.target}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="text-7xl font-black text-emerald-500 font-mono tracking-tighter"
          >
            {gameState.target}
          </motion.div>
          
          {/* Progress Bar for Time Mode */}
          {gameState.mode === 'time' && (
            <div className="w-48 h-1 bg-zinc-900 rounded-full mx-auto mt-4 overflow-hidden">
              <motion.div 
                className="h-full bg-amber-500"
                initial={false}
                animate={{ width: `${(gameState.timeLeft / TIME_LIMIT) * 100}%` }}
                transition={{ duration: 0.1, ease: "linear" }}
              />
            </div>
          )}
        </div>

        {/* The Grid */}
        <div 
          className="relative bg-zinc-900/50 p-2 rounded-2xl border border-zinc-800 shadow-2xl backdrop-blur-sm"
          style={{
            display: 'grid',
            gridTemplateColumns: `repeat(${GRID_COLS}, 1fr)`,
            gridTemplateRows: `repeat(${GRID_ROWS}, 1fr)`,
            gap: '6px',
            width: 'min(90vw, 400px)',
            aspectRatio: `${GRID_COLS} / ${GRID_ROWS}`
          }}
        >
          <AnimatePresence mode="popLayout">
            {gameState.grid.map((row, rIdx) => 
              row.map((block, cIdx) => (
                <div 
                  key={`${rIdx}-${cIdx}`}
                  className="relative aspect-square rounded-lg border border-zinc-800/50 bg-zinc-950/30"
                >
                  {block && (
                    <motion.button
                      layoutId={block.id}
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ 
                        scale: 1, 
                        opacity: 1,
                        backgroundColor: gameState.selectedIds.includes(block.id) ? '#10b981' : '#18181b',
                        borderColor: gameState.selectedIds.includes(block.id) ? '#34d399' : '#27272a',
                      }}
                      exit={{ scale: 0, opacity: 0 }}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleBlockClick(block)}
                      className={`absolute inset-0 flex items-center justify-center rounded-lg border-2 shadow-lg transition-colors duration-200 z-10`}
                    >
                      <span className={`text-xl font-bold font-mono ${gameState.selectedIds.includes(block.id) ? 'text-zinc-950' : 'text-zinc-100'}`}>
                        {block.value}
                      </span>
                    </motion.button>
                  )}
                </div>
              ))
            )}
          </AnimatePresence>
        </div>

        {/* Current Selection Sum */}
        <div className="mt-8 flex items-center gap-4 relative z-10">
          <div className="flex flex-col items-center">
            <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest mb-1">Current Sum</div>
            <div className={`text-3xl font-bold font-mono px-6 py-2 rounded-xl border-2 transition-all ${
              currentSum > gameState.target 
                ? 'bg-rose-500/10 border-rose-500 text-rose-500' 
                : currentSum === 0 
                  ? 'bg-zinc-900 border-zinc-800 text-zinc-500'
                  : 'bg-emerald-500/10 border-emerald-500 text-emerald-500'
            }`}>
              {currentSum}
            </div>
          </div>
        </div>
      </main>

      {/* Overlay Screens */}
      <AnimatePresence>
        {isPaused && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-zinc-950/80 backdrop-blur-md flex items-center justify-center p-6"
          >
            <div className="text-center space-y-6">
              <h2 className="text-4xl font-bold italic tracking-tighter">PAUSED</h2>
              <button 
                onClick={() => setIsPaused(false)}
                className="w-full py-4 bg-emerald-500 text-zinc-950 font-bold rounded-xl hover:bg-emerald-400 transition-colors flex items-center justify-center gap-2"
              >
                <Play className="w-5 h-5" /> RESUME
              </button>
              <button 
                onClick={resetGame}
                className="w-full py-4 bg-zinc-900 text-zinc-100 font-bold rounded-xl hover:bg-zinc-800 transition-colors flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-5 h-5" /> RESTART
              </button>
            </div>
          </motion.div>
        )}

        {gameState.gameOver && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-rose-950/90 backdrop-blur-xl flex items-center justify-center p-6"
          >
            <div className="text-center space-y-8 max-w-xs w-full">
              <div className="space-y-2">
                <AlertCircle className="w-16 h-16 text-rose-500 mx-auto" />
                <h2 className="text-5xl font-black tracking-tighter italic">GAME OVER</h2>
                <p className="text-rose-200/60 font-mono text-xs uppercase tracking-[0.3em]">Blocks Reached the Top</p>
              </div>

              <div className="bg-zinc-950/50 p-6 rounded-2xl border border-rose-500/20 space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-rose-200/50 font-mono text-xs uppercase">Final Score</span>
                  <span className="text-3xl font-bold font-mono">{gameState.score}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-rose-200/50 font-mono text-xs uppercase">Mode</span>
                  <span className="text-sm font-bold uppercase">{gameState.mode}</span>
                </div>
              </div>

              <div className="grid gap-3">
                <button 
                  onClick={resetGame}
                  className="w-full py-4 bg-zinc-100 text-zinc-950 font-bold rounded-xl hover:bg-white transition-colors flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-5 h-5" /> TRY AGAIN
                </button>
                <button 
                  onClick={() => setGameState(null)}
                  className="w-full py-4 bg-transparent border border-zinc-100/20 text-zinc-100 font-bold rounded-xl hover:bg-zinc-100/10 transition-colors"
                >
                  MAIN MENU
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer Info */}
      <footer className="p-4 border-t border-zinc-900 bg-zinc-950 text-center">
        <p className="text-[10px] font-mono text-zinc-600 uppercase tracking-[0.3em]">
          Select numbers to reach the target sum
        </p>
      </footer>
    </div>
  );
}
